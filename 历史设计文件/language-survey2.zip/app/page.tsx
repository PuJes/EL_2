import SurveyPage from "../SurveyPage"

export default function Page() {
  return <SurveyPage />
}
