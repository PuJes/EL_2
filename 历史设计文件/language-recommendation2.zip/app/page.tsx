import RecommendationPage from "@/components/language-recommendation-page"

export default function Home() {
  return <RecommendationPage />
}
